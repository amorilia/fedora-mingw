// SandBoxDBus.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <tchar.h>

#include "echo-client-win.h"
#include <windows.h>

unsigned long WINAPI dispthreadfct(void*a)
{
	DBus::default_dispatcher->enter();
	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	DBus::_init_threading();
	DBus::BusDispatcher* d = new DBus::BusDispatcher;
	DBus::default_dispatcher = d;
	DBus::Connection c = DBus::Connection::SessionBus();
	c.request_name("com.test");
	EchoProxy * pep = new EchoProxy(c);

	CreateThread(NULL, NULL, dispthreadfct, NULL, NULL, NULL);
	const int out_step = 1000;
	for (int i = 0; i < 100000; i++)
	{
		std::cout << i *out_step << std::endl;
		for (int k=0; k < out_step; k++)
			pep->Hello("test");
	}
	return 0;
}





EchoProxy::EchoProxy(DBus::Connection& conn)
: ObjectProxy(conn, "/org/freedesktop/DBus/Examples/Echo", "org.freedesktop.DBus.Examples.Echo")
{
}

EchoProxy::~EchoProxy(void)
{
}

void EchoProxy::Echoed( const ::DBus::Variant& value )
{
}
