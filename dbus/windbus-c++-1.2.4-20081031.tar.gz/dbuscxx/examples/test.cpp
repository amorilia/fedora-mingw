
#include <dbus-c++/dbus.h>

int main(int argc, char *argv)
{
	DBus::Connection x = DBus::Connection::SessionBus();
	if (x.connected())
		printf("connect to DBus\n");
	else 
		printf("could not connect to DBus\n");
}



