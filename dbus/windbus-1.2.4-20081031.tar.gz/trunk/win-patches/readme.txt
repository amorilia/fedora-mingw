Patches in this directory are handed for integration into dbus cvs but are not committed in dbus cvs. 

If patches are committed, a cvs update as decribed in ../README.win should be performed.  
Then the related patches in this dir could be deleted.
